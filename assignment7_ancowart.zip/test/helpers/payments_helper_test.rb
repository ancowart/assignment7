require 'test_helper'

class PaymentsHelperTest < ActionView::TestCase
end
