require 'test_helper'

class RepairRequestsHelperTest < ActionView::TestCase
end
