class Property < ActiveRecord::Base
  has_many :units
end
